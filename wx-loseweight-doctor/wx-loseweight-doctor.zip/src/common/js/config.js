export const homePage = `http://weixin.wincome.group/login`
export const authPageBaseUri = 'https://open.weixin.qq.com/connect/oauth2/authorize'
export const wechatAppId = 'wx99fcb86f4cb3700a'
