// export default {
//     HouseId(state){
//         return state.id
//     }
// }
