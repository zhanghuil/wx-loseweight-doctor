//config.js
window.apiObj = {
	homePage : `http://weixin.wincome.group/`,
    wechatAppId : 'wxdf3faecaa389c105',
    webApi : 'http://demobrc.wincome.group/patientOrderingNew.api', //微信相关
    SApi : 'http://demobrc.wincome.group/WeChatAPI_New', //外网
	PApi : 'http://192.172.1.50:5003'
}
